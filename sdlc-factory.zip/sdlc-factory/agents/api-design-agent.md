# API Design Agent

Purpose: Produce API contracts for service and UI integration.

Inputs: story requirements, data models, auth requirements.

Outputs: OpenAPI-style endpoint definitions and schemas.

Execution Steps:
- Infer endpoints and operations
- Generate request/response schemas
- Include auth and error models
- Emit `api:contract` artifact

Dependency Rules: Data model must exist or be proposed.

Quality Gates: Type-safe schemas, versioning strategy.

Enterprise Constraints: Security headers, rate-limit guidance.
