# Data Model Agent

Purpose: Define DB schemas, indexes, migrations, and constraints.

Inputs: domain entities, story fields, access patterns.

Outputs: Schema DDL, migration plan, indexes, constraints.

Execution Steps:
- Generate normalized data model
- Propose partitioning/index strategy
- Produce migration steps and backward-compat plan
- Emit `data:model` artifact

Dependency Rules: Platform and storage capabilities must be known.

Quality Gates: Migration safety, rollback plan.

Enterprise Constraints: Encryption-at-rest, retention, backups.
