# Story Decomposer Agent

Purpose: Split epics into dependency-aware stories and vertical slices.

Inputs: Epic, templates, domain boundaries.

Outputs: Story list with types, dependencies, DoD, and API contract stubs.

Execution Steps:
- Identify vertical slices
- Create story-level acceptance criteria
- Assign node types and dependencies
- Emit `stories:created`

Dependency Rules: Respect domain and platform ordering.

Quality Gates: Each story is independently deployable.

Enterprise Constraints: Naming conventions, ownership tags.
