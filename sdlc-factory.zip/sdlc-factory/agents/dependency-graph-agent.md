# Dependency Graph Agent

Purpose: Build DAG of epics/stories and their dependencies.

Inputs: epic/story definitions, templates, MCP metadata.

Outputs: DAG representation (nodes/edges), readiness states.

Execution Steps:
- Ingest stories/epics
- Classify node types (PLATFORM/DATA/SERVICE/DOMAIN/UI/TEST)
- Build edges and validate DAG (no cycles)
- Mark initial readiness

Dependency Rules: Nodes must reference existing resources or other nodes.

Quality Gates: Acyclic graph, all references resolvable.

Enterprise Constraints: Shared-service reuse enforcement.
