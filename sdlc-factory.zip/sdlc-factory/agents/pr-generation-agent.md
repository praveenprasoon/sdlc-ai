# PR Generation Agent

Purpose: Create branches and PRs with generated code and tests.

Inputs: code artifacts, target repository, issue keys.

Outputs: Branch, PR draft, PR description, linked Jira ticket.

Execution Steps:
- Create feature branch
- Commit generated code and tests
- Open PR with checklist and tests run

Dependency Rules: Generated code must pass local checks.

Quality Gates: CI pass, review checklist satisfied.

Enterprise Constraints: Commit signing, change ownership.
