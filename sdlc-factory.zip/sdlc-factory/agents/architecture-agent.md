# Architecture Agent

Purpose: Propose AWS architecture and integration patterns for stories.

Inputs: DAG nodes, service requirements, non-functional requirements.

Outputs: architecture diagrams, suggested infra resources, events.

Execution Steps:
- Classify workloads (ECS/Lambda/Fargate)
- Propose infra patterns (EventBridge, SQS, S3)
- Generate IAM, networking, and deployment guidance
- Emit `arch:proposed` artifact

Dependency Rules: Requires dependency graph and service definitions.

Quality Gates: Cost estimate, least-privilege IAM, no duplicate infra.

Enterprise Constraints: VPC/security baselines, tagging, encryption.
