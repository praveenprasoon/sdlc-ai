# Epic Generator Agent

Purpose: Convert intake brief into formal Epic(s) and high-level scope.

Inputs: normalized idea brief, domain map, business priority.

Outputs: Epic definitions, scope, success metrics, dependency hints.

Execution Steps:
- Map business goal to domains
- Generate epic text and acceptance criteria
- Identify dependencies and required platforms/data
- Emit `epic:created` event

Dependency Rules: Requires validated intake brief.

Quality Gates: Clear success metrics, scope boundaries, dependency list.

Enterprise Constraints: Compliance tags, org-level approval requirement.
