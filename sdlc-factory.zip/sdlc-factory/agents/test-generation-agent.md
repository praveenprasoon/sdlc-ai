# Test Generation Agent

Purpose: Generate unit, integration, contract, and E2E tests.

Inputs: code contracts, API schemas, data models.

Outputs: Test suites, mock fixtures, CI integrations.

Execution Steps:
- Generate unit test skeletons
- Generate integration and contract tests
- Wire tests into CI pipeline

Dependency Rules: Code or contract artifacts must exist.

Quality Gates: Coverage targets, deterministic tests.

Enterprise Constraints: Test data policies, secrets handling.
