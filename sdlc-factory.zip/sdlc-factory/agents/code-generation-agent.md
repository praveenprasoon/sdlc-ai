# Code Generation Agent

Purpose: Generate scaffolding and implementation for services and UI.

Inputs: API contracts, data models, infra plan, story DoD.

Outputs: Code skeletons, tests, Dockerfiles, build scripts.

Execution Steps:
- Emit code for endpoints and data layers
- Create CI-friendly project structure
- Run linters and basic static analysis

Dependency Rules: Contracts and models must be present.

Quality Gates: Linting, security scans, compile success.

Enterprise Constraints: Language/runtime standards, OSS policy.
