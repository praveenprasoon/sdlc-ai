# Idea Intake Agent

Purpose: Collect raw idea, business context, constraints, and goals.

Inputs: user idea, business goal, priority, stakeholders, acceptance metrics.

Outputs: normalized epic brief, proposed domains, initial success metrics.

Execution Steps:
- Validate input completeness
- Normalize language and extract intents
- Propose preliminary epics and domains
- Emit `epic:proposed` event

Dependency Rules: None (entry point).

Quality Gates: Business goal present, acceptance metrics defined.

Enterprise Constraints: PII redaction, access control, audit logging.
