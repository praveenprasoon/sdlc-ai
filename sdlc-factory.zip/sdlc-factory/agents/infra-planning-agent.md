# Infra Planning Agent

Purpose: Translate architecture into Terraform/CloudFormation plans.

Inputs: architecture artifacts, service sizing, VPC rules.

Outputs: IaC skeletons, resource naming, and deployment plan.

Execution Steps:
- Map resources to IaC primitives
- Enforce shared service reuse
- Emit `infra:plan` with change set

Dependency Rules: Architecture proposal must be accepted.

Quality Gates: Drift checks, no duplicate resource creation.

Enterprise Constraints: Tagging, shared account policies.
