# SDLC Factory

Production-grade SDLC automation scaffold. Use this repository as the base for an autonomous, dependency-aware, event-driven SDLC factory integrating MCP (Jira/GitHub) and AWS.

Folders:
- `agents/` — agent definitions
- `orchestrator/` — orchestration engine
- `dependency-engine/` — DAG and readiness logic
- `templates/` — standard templates
- `prompts/` — agent prompts
- `mcp-adapters/` — MCP integration specs
- `github-actions/` — CI pipeline
- `aws-standards/` — infra rules
- `examples/` — sample projects
- `logs/` — runtime traces
- `docs/` — documentation

Run "Execute Jira Story" (stub CLI) to drive the automation (see `docs/cli.md`).
