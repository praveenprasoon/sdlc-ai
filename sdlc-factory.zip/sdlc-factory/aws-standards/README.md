# AWS Standards

Defines shared infra models and patterns used by the SDLC factory.

Topics:
- Shared infrastructure model
- Event-driven architecture rules (EventBridge/SQS)
- ECS/Lambda usage guidance
- S3/SQS/EventBridge patterns
- IAM least privilege rules

Constraints: enforce tagging, encryption, multi-account separation.
