# UI Specs

Review Dashboard:
- List of processed documents
- Document detail with extracted fields and edit controls

Dependencies: calls `GET /documents/{id}` and `POST /extraction/{id}`
