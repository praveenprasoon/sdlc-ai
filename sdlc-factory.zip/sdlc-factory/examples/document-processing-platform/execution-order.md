# Execution Order

1. platform:shared-storage
2. data:document-schema
3. service:ocr
4. service:extraction
5. ui:review-dashboard
6. test:integration
