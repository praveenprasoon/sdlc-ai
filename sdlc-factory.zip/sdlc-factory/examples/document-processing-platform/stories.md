# Stories

- Story: Ingest document (PLATFORM/DATA)
- Story: Run OCR (SERVICE)
- Story: Extract fields (DOMAIN)
- Story: Review extraction (UI)
- Story: Integration tests (TEST)
