# Data Model

Entities:
- Document { id, uploaded_at, storage_uri, status }
- ExtractedRecord { id, document_id, schema, payload }

Indexes: document.status, created_at
