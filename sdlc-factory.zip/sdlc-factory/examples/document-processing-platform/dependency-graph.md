# Example Dependency Graph

Nodes:
- platform:shared-storage
- data:document-schema
- service:ocr
- service:extraction
- ui:review-dashboard
- test:integration

Edges: extraction -> ocr, extraction -> document-schema, ui -> extraction
