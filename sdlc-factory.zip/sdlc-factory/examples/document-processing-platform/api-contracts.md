# API Contracts

- `POST /documents` - upload document
- `GET /documents/{id}` - fetch metadata
- `POST /extraction/{id}` - trigger extraction

Schemas: see `templates/api-template.md` for structure.
