# GitHub MCP Client

Required functions:
- `createBranch(repo, base, name)`
- `createPR(repo, branch, title, body)`
- `getPRStatus(pr)`
- `getCommit(commit)`
- `linkToIssue(pr, issueId)`

Auth: GitHub App or PAT

Mapping: map PR and commit metadata into execution trace
