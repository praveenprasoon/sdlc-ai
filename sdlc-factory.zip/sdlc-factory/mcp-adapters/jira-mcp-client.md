# Jira MCP Client

Required functions:
- `getEpic(epicId)` — fetch epic and child stories
- `getStory(storyId)` — fetch story details
- `getDependencies(issueId)` — list linked issues
- `updateStatus(issueId, status, comment)` — update issue
- `syncJira(payload)` — bidirectional sync

Auth: OAuth or PAT via secure store

Mapping: map Jira fields to internal node metadata
