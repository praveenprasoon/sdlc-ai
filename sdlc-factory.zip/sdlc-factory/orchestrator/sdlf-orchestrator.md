# SDLC Orchestrator

Responsibilities:
1. Fetch Jira Epic/Story via MCP
2. Build dependency graph
3. Classify nodes: PLATFORM / DATA / SERVICE / DOMAIN / UI / TEST
4. Check readiness state
5. Block execution if dependencies missing
6. Execute only READY nodes
7. Generate design, code, tests, PR, and Jira update

Execution flow:
- `fetchContext()` -> `buildDAG()` -> `computeOrder()` -> loop nodes:
  - `checkReadiness(node)` -> if READY run agent chain -> emit events -> `jiraSync`

Traceability: all events logged to `logs/` and linked to Jira/PR.
