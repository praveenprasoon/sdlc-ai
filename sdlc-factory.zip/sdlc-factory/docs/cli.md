# CLI: Execute Jira Story

Purpose: single command to trigger the orchestrator for a given Jira story.

Usage:

On Windows (PowerShell):

```powershell
python tools/execute_jira_story.py --issue KEY-123
```

What it does:
- Fetches context via MCP
- Builds dependency graph
- Validates readiness
- Executes agents in order
- Creates PR and updates Jira

This repo includes a lightweight stub at `tools/execute_jira_story.py` to be wired to real MCP adapters.
