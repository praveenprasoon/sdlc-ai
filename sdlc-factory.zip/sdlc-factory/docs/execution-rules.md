# Execution Rules

RULE 1: No DOMAIN story executes before PLATFORM + DATA + SERVICE are READY.

RULE 2: No UI exists without API contract.

RULE 3: No duplicate AWS infra is created per story.

RULE 4: All stories must be independently deployable vertical slices.

RULE 5: Shared services must be reused, never duplicated.

RULE 6: All execution must be event-driven and traceable.

Enforcement: readiness-checker and DAG validation raise BLOCKED states with remediation guidance.
