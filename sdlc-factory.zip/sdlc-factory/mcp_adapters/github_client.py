"""Lightweight GitHub MCP client stub for SDLC Factory.

Methods are thin wrappers around GitHub REST API; production use should use PyGitHub
or GitHub App credentials and handle retries/rate-limits.
"""
import os
import requests
from typing import Any, Dict, Optional


class GitHubMCPClient:
    def __init__(self, token: Optional[str] = None, api_url: Optional[str] = None):
        self.token = token or os.environ.get('GITHUB_TOKEN')
        self.api_url = api_url or 'https://api.github.com'
        self.headers = {
            'Authorization': f'token {self.token}' if self.token else '',
            'Accept': 'application/vnd.github+json'
        }

    def _req(self, method: str, path: str, **kwargs) -> requests.Response:
        url = f"{self.api_url.rstrip('/')}/{path.lstrip('/')}"
        resp = requests.request(method, url, headers=self.headers, **kwargs)
        resp.raise_for_status()
        return resp

    def createBranch(self, owner: str, repo: str, base: str, name: str) -> Dict[str, Any]:
        # Get base commit
        ref = self._req('GET', f'repos/{owner}/{repo}/git/ref/heads/{base}').json()
        sha = ref['object']['sha']
        payload = {'ref': f'refs/heads/{name}', 'sha': sha}
        resp = self._req('POST', f'repos/{owner}/{repo}/git/refs', json=payload)
        return resp.json()

    def createPR(self, owner: str, repo: str, head: str, base: str, title: str, body: str) -> Dict[str, Any]:
        payload = {'title': title, 'head': head, 'base': base, 'body': body}
        resp = self._req('POST', f'repos/{owner}/{repo}/pulls', json=payload)
        return resp.json()

    def getPRStatus(self, owner: str, repo: str, pr_number: int) -> Dict[str, Any]:
        resp = self._req('GET', f'repos/{owner}/{repo}/pulls/{pr_number}')
        return resp.json()

    def getCommit(self, owner: str, repo: str, commit_sha: str) -> Dict[str, Any]:
        resp = self._req('GET', f'repos/{owner}/{repo}/commits/{commit_sha}')
        return resp.json()

    def linkToIssue(self, owner: str, repo: str, pr_number: int, issue_key: str) -> Dict[str, Any]:
        # Stub: add a comment linking PR to Jira issue
        body = f'Linked to Jira issue {issue_key}'
        resp = self._req('POST', f'repos/{owner}/{repo}/issues/{pr_number}/comments', json={'body': body})
        return resp.json()
