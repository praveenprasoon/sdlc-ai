"""Lightweight Jira MCP client stub for SDLC Factory.

This module provides a small class with the required methods described in the spec.
Implementations should replace the HTTP placeholders with proper Jira API calls or MCP client SDK.
"""
import os
import requests
from typing import Any, Dict, List, Optional


class JiraMCPClient:
    def __init__(self, base_url: Optional[str] = None, token: Optional[str] = None):
        self.base_url = base_url or os.environ.get('JIRA_BASE_URL')
        self.token = token or os.environ.get('JIRA_API_TOKEN')
        self.headers = {
            'Authorization': f'Bearer {self.token}' if self.token else '',
            'Content-Type': 'application/json'
        }

    def _req(self, method: str, path: str, **kwargs) -> requests.Response:
        url = f"{self.base_url.rstrip('/')}/{path.lstrip('/')}"
        resp = requests.request(method, url, headers=self.headers, **kwargs)
        resp.raise_for_status()
        return resp

    def getEpic(self, epic_id: str) -> Dict[str, Any]:
        """Fetch epic and child stories. Return dict with epic metadata."""
        # Placeholder: replace with Jira API call
        resp = self._req('GET', f'rest/api/2/issue/{epic_id}')
        return resp.json()

    def getStory(self, story_id: str) -> Dict[str, Any]:
        """Fetch a single story issue."""
        resp = self._req('GET', f'rest/api/2/issue/{story_id}')
        return resp.json()

    def getDependencies(self, issue_id: str) -> List[str]:
        """Return list of linked issue keys this issue depends on."""
        issue = self.getStory(issue_id)
        links = []
        for link in issue.get('fields', {}).get('issuelinks', []):
            if 'outwardIssue' in link:
                links.append(link['outwardIssue']['key'])
            if 'inwardIssue' in link:
                links.append(link['inwardIssue']['key'])
        return links

    def updateStatus(self, issue_id: str, status: str, comment: Optional[str] = None) -> Dict[str, Any]:
        """Transition issue status and optionally add a comment. This is a stub implementation."""
        # Real implementation needs to find transition id by name and call transitions API
        if comment:
            self._req('POST', f'rest/api/2/issue/{issue_id}/comment', json={'body': comment})
        # Return a stubbed response
        return {'issue': issue_id, 'status': status}

    def createBranch(self, repo: str, base: str, name: str) -> Dict[str, Any]:
        """Create a branch record in Jira development panel (or proxy to GitHub). Stubbed."""
        return {'repo': repo, 'base': base, 'branch': name}

    def createPR(self, repo: str, branch: str, title: str, body: str) -> Dict[str, Any]:
        """Create a PR reference in Jira or via MCP. Real PR creation should be done via GitHub client."""
        return {'repo': repo, 'branch': branch, 'title': title}

    def syncJira(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Perform a bidirectional sync. Stubbed to echo the payload."""
        # Implement mapping and idempotent updates in production
        return {'synced': True, 'payload': payload}
