# Story Template

- Type: UI/API/DATA/INFRA/TEST/INT
- Description: |
- Acceptance criteria: |
- Dependencies: node keys
- API contracts: references or inline
- DB changes: migration notes
- Events emitted: event names and schema
- Definition of Done: checklist
