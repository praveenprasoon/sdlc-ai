# Epic Template

- Business goal: |
- Scope: |
- Dependency summary: list of required platforms/data/services
- Domain breakdown: per-domain responsibilities
- Success metrics: quantitative targets and measurement plan
