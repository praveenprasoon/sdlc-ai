# Test Template

- Unit tests: scope and examples
- Integration tests: data and services interactions
- Contract tests: API consumer-provider contracts
- E2E tests: happy-path and negative cases
