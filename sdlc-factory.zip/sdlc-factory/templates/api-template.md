# API Template

- Endpoint definition: method + path
- Request schema: JSON Schema / OpenAPI components
- Response schema: JSON Schema
- Auth requirements: scopes/roles
- Event emissions: which events, payloads
- Consumers: internal/external services
