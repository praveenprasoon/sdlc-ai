# Infra Template

- AWS resources: list of resources and purpose
- Shared services rules: reuse policies
- IAM policies: least-privilege examples
- Deployment strategy: staging -> prod promotion
