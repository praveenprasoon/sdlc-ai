# UI Template

- Figma-ready spec: page layout and component mapping
- Screens: list with descriptions
- States: primary states for each screen
- API dependencies: endpoints and contracts
