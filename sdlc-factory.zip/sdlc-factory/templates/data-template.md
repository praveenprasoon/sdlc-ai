# Data Template

- Schema definition: entities and fields
- Indexes: indexes and rationale
- Migration strategy: backward-compatible steps
- Constraints: FK, uniqueness, validation rules
