# Readiness Checker

Checks required before executing a node:

- All upstream dependencies have state READY.
- For DOMAIN nodes: PLATFORM and DATA readiness enforced.
- For UI nodes: API contract must be present and stable.
- No conflicting infra claims.

Returns: READY / BLOCKED with diagnostics and remediation hints.
