# Execution Ordering

Compute execution order by topological sort over DAG, with tie-breakers:

- Prefer PLATFORM and DATA first
- Services required by multiple domains run before dependent DOMAIN nodes
- Tests run after code and infra readiness

Output: ordered queue of executable nodes with readiness checks attached.
