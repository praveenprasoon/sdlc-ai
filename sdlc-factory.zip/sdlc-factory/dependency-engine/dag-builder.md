# DAG Builder

Purpose: Canonical builder for dependency DAGs where every story/epic is a node.

Key rules:
- Nodes: PLATFORM / DATA / SERVICE / DOMAIN / UI / TEST / RELEASE
- Edges represent 'depends-on'
- Validate acyclic property

Output: Serialized DAG (JSON) with node metadata and readiness flags.

Usage: DAG is used by orchestrator to compute execution order and readiness.
