# Dependency Rules

Fundamental rules for DAG nodes:

- Everything is a DAG node.
- Node types: PLATFORM / DATA / SERVICE / DOMAIN / UI / TEST / RELEASE.
- PLATFORM and DATA must exist before DOMAIN executes.
- UI depends on API contracts.
- Shared services are singletons; reuse enforced.

Validation: tooling MUST detect cycles, missing dependencies, and duplicate infra claims.
